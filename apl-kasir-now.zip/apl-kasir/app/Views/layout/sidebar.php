<!-- ======= Sidebar ======= -->
<aside id="sidebar" class="sidebar">

  <ul class="sidebar-nav" id="sidebar-nav">

    <li class="nav-item">
      <a class="nav-link collapsed" href="<?= site_url('dashboard-admin'); ?>">
        <i class="bi bi-grid-1x2"></i>
        <span>Dashboard</span>
      </a>
    </li><!-- End Dashboard Nav -->

    <li class="nav-heading">Master Data</li>

    <li class="nav-item">
      <a class="nav-link collapsed" href="<?= base_url('data-kategori'); ?>">
        <i class="bi bi-card-list"></i>
        <span>Kategori Produk</span>
      </a>
    </li><!-- End Kategori Page Nav -->
    <li class="nav-item">
      <a class="nav-link collapsed" href="<?= base_url('data-satuan'); ?>">
        <i class="bi bi-card-list"></i>
        <span>Satuan Produk</span>
      </a>
    </li><!-- End Satuan Page Nav -->
    <li class="nav-item">
      <a class="nav-link collapsed" href="<?= base_url('data-produk'); ?>">
        <i class="bi bi-journal-text"></i>
        <span>Produk</span>
      </a>
    </li><!-- End Produk Page Nav -->
    <li class="nav-item">
      <a class="nav-link collapsed" href="<?= base_url('data-user'); ?>">
        <i class="bi bi-people"></i>
        <span>Pengguna</span>
      </a>
    </li><!-- End Pengguna Page Nav -->

    <li class="nav-heading">Transaksi</li>

    <li class="nav-item">
      <a class="nav-link collapsed" href="<?= base_url('form-penjualan'); ?>">
        <i class="bi bi-basket"></i>
        <span>Penjualan</span>
      </a>
    </li><!-- End Kategori Page Nav -->

    <li class="nav-heading">Laporan</li>

    <li class="nav-item">
      <a class="nav-link collapsed" href="">
        <i class="bi bi-bar-chart-line"></i>
        <span>Stok Barang</span>
      </a>
    </li><!-- End Login Page Nav -->

  </ul>

</aside><!-- End Sidebar-->