<?= $this->extend('layout/template'); ?>

<?= $this->section('content'); ?>

<main id="main" class="main">

    <!-- <div class="pagetitle">
        <h1>Data Kategori Produk</h1>
        <nav>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="index.html">Dashboard</a></li>
                <li class="breadcrumb-item">Master Data</li>
                <li class="breadcrumb-item active">Kategori Produk</li>
            </ol>
        </nav>
    </div> -->
    <!-- End Page Title -->

    <section class="section">
        <div class="row">
            <div class="col-lg-12">

                <div class="card md-12">
                    <div class="card-body">
                        <h1 class="card-title">Form Penjualan</h1>

                        <!-- Floating Labels Form -->
                        <form class="row g-3">
                            <div class="col-md-3">
                                <div class="form-floating">
                                    <input type="text" class="form-control" id="floatingName" value="<?= $noFaktur; ?>"
                                        disabled>
                                    <label for="floatingName">Nomor Faktur</label>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="form-floating">
                                    <input type="email" class="form-control" id="floatingEmail"
                                        value="<?php echo date("d-m-Y"); ?>" disabled>
                                    <label for="floatingEmail">Tanggal Penjualan</label>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="form-floating">
                                    <input type="text" class="form-control" id="floatingPassword"
                                        value="<?php echo date("h:i:sa"); ?>" disabled>
                                    <label for="floatingPassword">Waktu</label>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="col-md-12">
                                    <div class="form-floating">
                                        <input type="text" class="form-control" id="floatingCity" placeholder="City"
                                            value="<?= session()->get('nama_user'); ?>" disabled>
                                        <label for="floatingCity">Kasir</label>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-floating">

                                    <select class="js-example-basic-single form-select" name="id_produk">
                                        <?php if (isset($produk)):
                                            foreach ($produk as $row): ?>
                                                <option value="<?= $row['id_produk']; ?>">
                                                    <?= $row['nama_produk']; ?> |
                                                    <?= $row['stok']; ?>
                                                    |
                                                    <?= number_format($row['harga_jual'], 0, ',', '.'); ?>
                                                </option>
                                                <?php
                                            endforeach;
                                        endif; ?>
                                    </select>

                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="form-floating">
                                    <input type="text" class="form-control" id="floatingPassword">
                                    <label for="floatingPassword">Jumlah</label>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="form-floating">
                                    <input type="text" class="form-control" id="floatingPassword">
                                    <label for="floatingPassword">Total</label>
                                </div>
                            </div>
                            <div class="col">
                                <button type="submit" class="btn btn-primary">Submit</button>
                                <button type="submit" class="btn btn-primary">Pembayaran</button>
                                <!-- <a type="reset" class="btn btn-secondary">Reset</a> -->
                            </div>
                        </form><!-- End floating Labels Form -->

                        <div class="row my-3">
                            <div class="col">
                                <!-- Default Table -->
                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th scope="col">No</th>
                                            <th scope="col">Kode Produk</th>
                                            <th scope="col">Nama Produk</th>
                                            <th scope="col">Satuan Produk</th>
                                            <th scope="col">Kategori Produk</th>
                                            <th scope="col">Harga Jual</th>
                                            <th scope="col">Stok</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td>
                                            </td>
                                            <td>
                                            </td>
                                            <td>
                                            </td>
                                            <td>
                                            </td>
                                            <td>
                                            </td>
                                            <td>
                                            </td>
                                            <td>
                                            </td>
                                            <td>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                                <!-- End Default Table Example -->
                            </div>
                        </div>

                    </div>
                </div>

            </div>
        </div>
    </section>

</main><!-- End #main -->

<?= $this->endSection(); ?>