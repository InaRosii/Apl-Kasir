<?php

namespace App\Models;

use CodeIgniter\Model;

class Mpenjualan extends Model
{
    protected $table = 'tbl_penjualan';
    protected $primaryKey = 'id_penjualan';
    protected $useAutoIncrement = true;
    protected $returnType = 'array';
    protected $useSoftDeletes = false;
    protected $protectFields = true;
    protected $allowedFields = ['id_penjualan', 'no_faktur', 'tanggal_penjualan', 'waktu', 'grand_total', 'id_user'];

    // Dates
    protected $useTimestamps = false;
    protected $dateFormat = 'datetime';
    protected $createdField = 'created_at';
    protected $updatedField = 'updated_at';
    protected $deletedField = 'deleted_at';

    // Validation
    protected $validationRules = [];
    protected $validationMessages = [];
    protected $skipValidation = false;
    protected $cleanValidationRules = true;

    // Callbacks
    protected $allowCallbacks = true;
    protected $beforeInsert = [];
    protected $afterInsert = [];
    protected $beforeUpdate = [];
    protected $afterUpdate = [];
    protected $beforeFind = [];
    protected $afterFind = [];
    protected $beforeDelete = [];
    protected $afterDelete = [];

    public function generateNoFaktur()
    {
        $prefix = 'PJLN';
        $lastFaktur = $this->orderBy('id_penjualan', 'DESC')->first();

        if (!$lastFaktur) {
            $code = $prefix . '0001';
        } else {
            $lastCode = substr($lastFaktur['no_faktur'], strlen($prefix));
            $nextCode = str_pad($lastCode + 1, 3, '0', STR_PAD_LEFT);
            $code = $prefix . $nextCode;
        }

        return $code; 
    }

    public function getPenjualan()
    {
        $produk = new Mproduk();
        $produk->select('tbl_penjualan.no_faktur, tbl_penjualan.tanggal_penjualan, tbl_penjualan.waktu, tbl_penjualan.grand_total, tbl_user.nama_user');
        $produk->join('tbl_user', 'tbl_user.id_user=tbl_penjualan.id_user', 'LEFT');
        $produk->orderBy('tbl_penjualan.id_penjualan', 'DESC');
        return $produk->find();
    }


}
