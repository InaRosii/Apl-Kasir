<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use CodeIgniter\HTTP\ResponseInterface;

class Penjualan extends BaseController
{
    public function index()
    {
        //
    }

    // public function dataPenjualan()
    // {
    //     $data = [
    //         'listPenjualan' => $this->penjualan->getPenjualan()
    //     ];
    //     return view('penjualan/penjualan', $data);
    // }

    public function tambahPenjualan()
    {
        $data = [
            'noFaktur' => $this->penjualan->generateNoFaktur(),
            'nama_user' => session()->get('nama_user'),
            date_default_timezone_set('Asia/Jakarta'),
            'produk' => $this->produk->getProduk()

        ];
        return view('penjualan/form-penjualan', $data);
    }

    public function simpanPenjualan()
    {
        // ambil detail barang yang dijual
        $where = ['id_produk' => $this->request->getPost('id_produk')];

        $cekBarang = $this->produk->where($where)->findAll();
        $hargaJual = $cekBarang[0]['harga_jual'];


        if (session()->get('IdPenjualan') == null) {
            // 1 nampung data penjualan
            $dataPenjualan = [
                'no_transaksi' => $this->request->getPost('no_transaksi'),
                'tgl_penjualan' => date('Y-m-d H:m=i:s'),
                'email' => session()->get('email'),
                'total' => 0
            ];

            //2 simpan ke tabel penjualan
            $this->penjualan->insert($dataPenjualan);

            //3 nyiapin data baut nyimpen detail
            $dataDetailPenjualan = [
                'id_penjualan' => $this->penjualan->insertID(),
                'id_produk' => $this->request->getPost('id_produk'),
                'qty' => $this->request->getPost('txtqty'),
                'total_harga' => $hargaJual * $this->request->getPost('txtqty')
            ];

            //4 simpan ke detail penjualan
            $this->detail->insert($dataDetailPenjualan);


            // 5 membuat session penualan
            session()->set('IdPenjualan', $this->penjualan->insertID());
        } else {

            //3 nyiapin data baut nyimpen detail
            $dataDetailPenjualan = [
                'id_penjualan' => session()->get('IdPenjualan'),
                'id_produk' => $this->request->getPost('id_produk'),
                'qty' => $this->request->getPost('txtqty'),
                'total_harga' => $hargaJual * $this->request->getPost('txtqty')
            ];

            //4 simpan ke detail penjualan
            $this->detail->insert($dataDetailPenjualan);

        }



        return redirect()->to('transaksi-penjualan');
    }

    public function simpanPembayaran()
    {
        session()->remove('IdPenjualan');
        return redirect()->to('transaksi-penjualan');

    }
}
